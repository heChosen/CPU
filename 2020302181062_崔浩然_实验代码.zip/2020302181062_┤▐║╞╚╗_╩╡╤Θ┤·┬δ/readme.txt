MCCPU_FPGA是多周期的FPGA文件
SCCPU是单周期FPGA文件

MCCPUsim为多周期modelsim文件
SCCPUSIM为单周期modelsim文件

test_code为自己添加指令时的编写的指令代码